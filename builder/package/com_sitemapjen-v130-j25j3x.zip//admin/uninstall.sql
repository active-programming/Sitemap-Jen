DROP TABLE IF EXISTS `#__sitemapjen_links`;
DROP TABLE IF EXISTS `#__sitemapjen_options`;