<?php
/**
 * Sitemap Jen
 * @author Konstantin@Kutsevalov.name
 * @package    sitemapjen
 */

defined('_JEXEC') or die('Restricted access');

echo 'Генератор Sitemap Jen';